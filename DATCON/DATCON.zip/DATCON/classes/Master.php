<?php
require_once('../config.php');
Class Master extends DBConnection {
	private $settings;
	public function __construct(){
		global $_settings;
		$this->settings = $_settings;
		parent::__construct();
	}
	public function __destruct(){
		parent::__destruct();
	}
	function capture_err(){
		if(!$this->conn->error)
			return false;
		else{
			$resp['status'] = 'failed';
			$resp['error'] = $this->conn->error;
			return json_encode($resp);
			exit;
		}
	}

	function save_consultant(){
		extract($_POST);
		$data = "";
		foreach($_POST as $k =>$v){
			if(!in_array($k,array('id'))){
				if(!is_numeric($v))
					$v = $this->conn->real_escape_string($v);
				if(!empty($data)) $data .=",";
				$data .= " `{$k}`='{$v}' ";
			}
		}
		if(empty($id)){
			$sql = "INSERT INTO `consultant` SET {$data} ";
		}else{
			$sql = "UPDATE `consultant` SET {$data} WHERE ConsultantID = '{$id}' ";
		}
		
		$save = $this->conn->query($sql);
		if($save){
			$rid = !empty($id) ? $id : $this->conn->insert_id;
			$resp['status'] = 'success';
			if(empty($id))
				$resp['msg'] = "Consultant details have been successfully added.";
			else
				$resp['msg'] = "Consultant details have been updated successfully.";
		}else{
			$resp['status'] = 'failed';
			$resp['msg'] = "An error occurred.";
			$resp['err'] = $this->conn->error."[{$sql}]";
		}
		if($resp['status'] =='success' && !empty($id))
		$this->settings->set_flashdata('success',$resp['msg']);
		if($resp['status'] =='success' && empty($id))
		$this->settings->set_flashdata('pop_msg',$resp['msg']);
		return json_encode($resp);
	}
	
	function delete_consultant(){
		extract($_POST);
		$del = $this->conn->query("DELETE FROM `consultant` WHERE ConsultantID = '{$id}'");
		if($del){
			$resp['status'] = 'success';
			$this->settings->set_flashdata('success',"Consultant has been deleted successfully.");
		}else{
			$resp['status'] = 'failed';
			$resp['error'] = $this->conn->error;
		}
		return json_encode($resp);
	}	

	function save_contractor(){
		extract($_POST);
		$data = "";
		foreach($_POST as $k =>$v){
			if(!in_array($k,array('id'))){
				if(!is_numeric($v))
					$v = $this->conn->real_escape_string($v);
				if(!empty($data)) $data .=",";
				$data .= " `{$k}`='{$v}' ";
			}
		}
		if(empty($id)){
			$sql = "INSERT INTO `contractor` SET {$data} ";
		}else{
			$sql = "UPDATE `contractor` SET {$data} WHERE ContractorID = '{$id}' ";
		}
		
		$save = $this->conn->query($sql);
		if($save){
			$rid = !empty($id) ? $id : $this->conn->insert_id;
			$resp['status'] = 'success';
			if(empty($id))
				$resp['msg'] = "Contractor details have been successfully added.";
			else
				$resp['msg'] = "Contractor details have been updated successfully.";
		}else{
			$resp['status'] = 'failed';
			$resp['msg'] = "An error occurred.";
			$resp['err'] = $this->conn->error."[{$sql}]";
		}
		if($resp['status'] =='success' && !empty($id))
		$this->settings->set_flashdata('success',$resp['msg']);
		if($resp['status'] =='success' && empty($id))
		$this->settings->set_flashdata('pop_msg',$resp['msg']);
		return json_encode($resp);
	}
	
	function delete_contractor(){
		extract($_POST);
		$del = $this->conn->query("DELETE FROM `contractor` WHERE ContractorID = '{$id}'");
		if($del){
			$resp['status'] = 'success';
			$this->settings->set_flashdata('success',"Contractor has been deleted successfully.");
		}else{
			$resp['status'] = 'failed';
			$resp['error'] = $this->conn->error;
		}
		return json_encode($resp);
	}	

	function delete_file(){
		extract($_POST);
		$id = isset($id) ? $id : ''; // Ensure $id is set to avoid errors
		$sql = "DELETE FROM `storage` WHERE `store_id` = '{$id}'";
		$delete = $this->conn->query($sql);
		if($delete){
			$resp['status'] = 'success';
			$resp['message'] = "File deleted successfully.";
		}else{
			$resp['status'] = 'error';
			$resp['message'] = "Error deleting file.";
		}
		echo json_encode($resp);
	}
	
	function save_grading() {
		global $conn;
	
		// Get data from POST request
		$entityID = $_POST['EntityID'];
		$entityType = $_POST['EntityType'];
		$qualityOfWork = $_POST['QualityOfWork'];
		$timeliness = $_POST['Timeliness'];
		$communication = $_POST['Communication'];
		$compliance = $_POST['Compliance'];
		$costEfficiency = $_POST['CostEfficiency'];
		$responsiveness = $_POST['Responsiveness'];
	
		// Calculate overall grade
		$overallGrade = ($qualityOfWork + $timeliness + $communication + $compliance + $costEfficiency + $responsiveness) / 6;
	
		// Insert grading data into the database
		$sql = "INSERT INTO grading (EntityID, EntityType, QualityOfWork, Timeliness, Communication, Compliance, CostEfficiency, Responsiveness, OverallGrade) 
				VALUES ('$entityID', '$entityType', '$qualityOfWork', '$timeliness', '$communication', '$compliance', '$costEfficiency', '$responsiveness', '$overallGrade')";
		
		if(mysqli_query($conn, $sql)) {
			$response = array("status" => "success");
		} else {
			$response = array("status" => "error");
		}
	
		echo json_encode($response);
	}

	function delete_grade() {
		extract($_POST);
		$del = $this->conn->query("DELETE FROM `grading` WHERE GradingID = '{$id}'");
		if($del){
			$resp['status'] = 'success';
			$this->settings->set_flashdata('success',"Grade has been deleted successfully.");
		} else {
			$resp['status'] = 'failed';
			$resp['error'] = $this->conn->error;
		}
		return json_encode($resp);
	}
	
	
	
}


$Master = new Master();
$action = !isset($_GET['f']) ? 'none' : strtolower($_GET['f']);
$sysset = new SystemSettings();
switch ($action) {

	case 'save_grading':
		echo $Master->save_grading();
	break;
	case 'delete_grade':
		echo $Master->delete_grade();
	break;
	case 'save_consultant':
        echo $Master->save_consultant();
        break;
    case 'delete_consultant':
        echo $Master->delete_consultant();
        break;
	case 'save_contractor':
        echo $Master->save_contractor();
        break;
    case 'delete_contractor':
        echo $Master->delete_contractor();
        break;
	case 'delete_file':
		echo $Master->delete_file();
	break;
	default:
		// echo $sysset->index();
		break;
}