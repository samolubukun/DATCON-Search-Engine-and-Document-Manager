<?php
require_once('../../config.php');

// Fetch data for dropdown menu
$sql = "SELECT CONCAT(c.FirstName, ' ', COALESCE(c.MiddleName, ''), ' ', c.LastName) AS FullName, c.ContractorID AS ID, 'Contractor' AS EntityType, c.CompanyName AS Company FROM contractor c
        UNION ALL
        SELECT CONCAT(co.FirstName, ' ', COALESCE(co.MiddleName, ''), ' ', co.LastName) AS FullName, co.ConsultantID AS ID, 'Consultant' AS EntityType, co.CompanyName AS Company FROM consultant co";
$result = mysqli_query($conn, $sql);

// Get the referring page URL
$referring_page = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : 'upload_success.php'; // Default to a success page

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $filename = $_FILES["file"]["name"];
    $tempname = $_FILES["file"]["tmp_name"];
    $file_type = $_POST["file_type"];
    $date_uploaded = date("Y-m-d H:i:s");
    $selected_option = explode('|', $_POST["contractor_consultant"]);
    $contractor_consultant_id = $selected_option[0];
    $contractor_consultant_type = $selected_option[1];

    // Move uploaded file to directory
    $target_dir = "files/";
    $target_file = $target_dir . basename($filename);
    move_uploaded_file($tempname, $target_file);

    // Insert data into storage table
    $insert_sql = "INSERT INTO storage (filename, file_type, date_uploaded, " . ($contractor_consultant_type == 'Contractor' ? 'contractor_id' : 'consultant_id') . ") 
                    VALUES ('$filename', '$file_type', '$date_uploaded', '$contractor_consultant_id')";
    mysqli_query($conn, $insert_sql);

    // Redirect back to the referring page
    header("Location: $referring_page");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document Upload Form</title>
</head>
<body>
    <h2>Upload Document</h2>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data">
        <label for="file">Choose File:</label><br>
        <input type="file" id="file" name="file" required><br><br>

        <label for="file_type">Document Type:</label><br>
        <input type="text" id="file_type" name="file_type" required><br><br>

        <label for="contractor_consultant">Select Contractor/Consultant:</label><br>
        <select id="contractor_consultant" name="contractor_consultant" required>
            <option value="">Select</option>
            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                <option value="<?php echo $row['ID'] . '|' . $row['EntityType']; ?>"><?php echo $row['FullName'] . ' (' . $row['EntityType'] . ') - ' . $row['Company']; ?></option>
            <?php } ?>
        </select><br><br>

        <input type="submit" value="Upload" name="submit">
    </form>
</body>
</html>
