<?php
require_once('../../config.php');

if (isset($_REQUEST['store_id'])) {
    $store_id = $_REQUEST['store_id'];
    
    $query = mysqli_query($conn, "SELECT * FROM `storage` WHERE `store_id` = '$store_id'") or die(mysqli_error($conn));
    $fetch  = mysqli_fetch_array($query);
    $filename = $fetch['filename'];
    $file_path = "files/" . $filename; // Assuming the files are stored directly in the 'files' directory

    // Check if the file exists
    if (file_exists($file_path)) {
        // Set the appropriate content type based on the file extension
        $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        switch ($extension) {
            case 'pdf':
                header('Content-Type: application/pdf');
                break;
            case 'jpg':
            case 'jpeg':
                header('Content-Type: image/jpeg');
                break;
            case 'png':
                header('Content-Type: image/png');
                break;
            // Add more cases for other file types if needed
            default:
                header('Content-Type: application/octet-stream');
                break;
        }
        
        // Output the file content
        readfile($file_path);
        exit;
    } else {
        echo "File not found.";
    }
}
?>