<?php
require_once('../../config.php');

if (isset($_REQUEST['store_id'])) {
    $store_id = $_REQUEST['store_id'];
    
    $query = mysqli_query($conn, "SELECT * FROM `storage` WHERE `store_id` = '$store_id'") or die(mysqli_error($conn));
    $fetch  = mysqli_fetch_array($query);
    $filename = $fetch['filename'];
    $file_path = "files/" . $filename; // Assuming the files are stored directly in the 'files' directory

    // Check if the file exists
    if (file_exists($file_path)) {
        header("Content-Disposition: attachment; filename=" . $filename);
        header("Content-Type: application/octet-stream");
        readfile($file_path);
        exit;
    } else {
        echo "File not found.";
    }
}
?>
