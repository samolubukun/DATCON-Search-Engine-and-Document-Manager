<?php if($_settings->chk_flashdata('success')): ?>
    <script>
        alert_toast("<?php echo $_settings->flashdata('success') ?>",'success')
    </script>
<?php endif; ?>

<style>
    .img-avatar{
        width:45px;
        height:45px;
        object-fit:cover;
        object-position:center center;
        border-radius:100%;
    }
    .table-container {
        overflow-x: auto;
    }
</style>

<div class="card card-outline card-primary">
    <div class="card-header">
        <h3 class="card-title">List of Uploaded Documents</h3>
        <div class="card-tools">
            <a href="javascript:void(0)" id="create_new" class="btn btn-flat btn-sm btn-primary"><span class="fas fa-plus"></span>  Add New Document</a>
        </div>
    </div>
    <div class="card-body">
        <div class="container-fluid table-container">
            <table class="table table-hover table-striped">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Date Uploaded</th>
                        <th>Document</th>
                        <th>Document Type</th>
                        <th>Consultant/Contractor</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                        $i = 1;
                        $qry = $conn->query("SELECT s.*, 
                            c.FirstName AS consultant_firstname, 
                            c.MiddleName AS consultant_middlename, 
                            c.LastName AS consultant_lastname,
                            c.CompanyName AS consultant_company,  
                            ct.FirstName AS contractor_firstname, 
                            ct.MiddleName AS contractor_middlename, 
                            ct.LastName AS contractor_lastname,
                            ct.CompanyName AS contractor_company
                     FROM `storage` s 
                     LEFT JOIN `consultant` c ON s.consultant_id = c.ConsultantID
                     LEFT JOIN `contractor` ct ON s.contractor_id = ct.ContractorID");

                        while($row = $qry->fetch_assoc()):
                    ?>
                        <tr>
                            <td class="text-center"><?php echo $i++; ?></td>
                            <td><?php echo $row['date_uploaded']; ?></td>
                            <td><?php echo $row['filename']; ?></td>
                            <td><?php echo $row['file_type']; ?></td>
                            <td>
                                <?php 
                                    // Displaying the consultant or contractor's Fullname alongside their ID
                                    if (!empty($row['consultant_firstname'])) {
                                        echo $row['consultant_firstname'].' '.$row['consultant_middlename'].' '.$row['consultant_lastname'].' - <strong>[Consultant]:</strong>'.$row['consultant_company']; 
                                    } elseif (!empty($row['contractor_firstname'])) {
                                        echo $row['contractor_firstname'].' '.$row['contractor_middlename'].' '.$row['contractor_lastname'].' - <strong>[Contractor]:</strong>'.$row['contractor_company']; 
                                    }
                                ?>
                            </td>
                            <td align="center">
                                <button type="button" class="btn btn-flat btn-default btn-sm dropdown-toggle dropdown-icon" data-toggle="dropdown">
                                    Action
                                    <span class="sr-only">Toggle Dropdown</span>
                                </button>
                                <div class="dropdown-menu" role="menu">
                                    <a class="dropdown-item delete_data" href="javascript:void(0)" data-id="<?php echo $row['store_id']; ?>">
                                        <span class="fa fa-trash text-danger"></span> Delete
                                    </a>
                                    <a class="dropdown-item view_file" href="javascript:void(0)" data-id="<?php echo $row['store_id']; ?>">
                                        <span class="fa fa-eye"></span> View
                                    </a>
                                    <a class="dropdown-item" href="documents/download.php?store_id=<?php echo $row['store_id']; ?>">
                                        <span class="fa fa-download"></span> Download
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal for view file -->
<div class="modal fade" id="viewModal" tabindex="-1" aria-labelledby="viewModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="viewModalLabel">View Document</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <iframe id="viewFrame" src="" style="width: 100%; height: 80vh; border: none;"></iframe>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function(){
        // Function to open the modal and load the content of view.php
        $('.view_file').click(function(){
            var storeId = $(this).attr('data-id');
            $('#viewFrame').attr('src', 'documents/view.php?store_id=' + storeId);
            $('#viewModal').modal('show');
        });

        // Other existing code...

        $('.delete_data').click(function(){
            _conf("Are you sure to delete this file permanently?","delete_file",[$(this).attr('data-id')])
        })
        $('#create_new').click(function(){
            uni_modal("Add New Document Details","documents/manage_file.php",'mid-large')
        })
        $('.table td,.table th').addClass('py-1 px-2 align-middle')
        $('.table').dataTable();
    })

    
    function delete_file($id){
        start_loader();
        $.ajax({
            url:_base_url_+"classes/Master.php?f=delete_file",
            method:"POST",
            data:{id: $id},
            dataType:"json",
            error:err=>{
                console.log(err)
                alert_toast("An error occurred.",'error');
                end_loader();
            },
            success:function(resp){
                if(typeof resp== 'object' && resp.status == 'success'){
                    location.reload();
                } else {
                    alert_toast("An error occurred.",'error');
                    end_loader();
                }
            }
        })
    }
</script>
