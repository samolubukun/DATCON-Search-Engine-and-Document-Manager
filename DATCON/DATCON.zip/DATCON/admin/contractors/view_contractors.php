<?php
function getLetterGrade($numericGrade) {
    if ($numericGrade >= 4.5) {
        return 'Excellent';
    } elseif ($numericGrade >= 3.5) {
        return 'Good';
    } elseif ($numericGrade >= 2.5) {
        return 'Average';
    } elseif ($numericGrade >= 1.5) {
        return 'Poor';
    } else {
        return 'Very Poor';
    }
}
if (isset($_GET['id']) && $_GET['id'] > 0) {
    $contractor_id = $_GET['id'];
    $contractor_qry = $conn->query("SELECT * from `contractor` where ContractorID = '{$contractor_id}' ");
    if ($contractor_qry->num_rows > 0) {
        $contractor_details = $contractor_qry->fetch_assoc();

        // Fetch associated document
        $document_qry = $conn->query("SELECT * FROM `storage` WHERE contractor_id = '{$contractor_id}'");

         // Fetch associated grading
         $grading_qry = $conn->query("SELECT * FROM `grading` WHERE EntityID = '{$contractor_id}' AND EntityType = 'Contractor'");
    } else {
        echo '<script>alert("Contractor ID is not valid."); location.replace("./?page=contractors")</script>';
    }
} else {
    echo '<script>alert("Contractor ID is Required."); location.replace("./?page=contractors")</script>';
}
?>
<style>
    legend.legend-sm {
        font-size: 1.4em;
    }

    #cimg {
        max-width: 100%;
        max-height: 20em;
        object-fit: scale-down;
        object-position: center center;
    }
</style>
<div class="content py-5 px-3 bg-gradient-navy">
    <h4 class="font-wight-bolder"><?= isset($contractor_details) ? "Contractor Details" : "Invalid Contractor ID" ?></h4>
</div>
<div class="row mt-n4 align-items-center justify-content-center flex-column">
    <div class="col-lg-10 col-md-11 col-sm-12 col-xs-12">
        <?php if (isset($contractor_details)): ?>
            <div class="card rounded-0 shadow">
                <div class="card-body">
                    <div class="container-fluid">
                        <div class="row">
                            <!-- Display consultant details -->
                            <div class="form-group col-lg-4 col-md-4 col-sm-12 col-xs-12">
                                <label for="FirstName" class="control-label">First Name:</label>
                                <div><?= isset($contractor_details['FirstName']) ? $contractor_details['FirstName'] : '' ?></div>
                            </div>
                            <div class="form-group col-lg-4 col-md-4 col-sm-12 col-xs-12">
                                <label for="MiddleName" class="control-label">Middle Name:</label>
                                <div><?= isset($contractor_details['MiddleName']) ? $contractor_details['MiddleName'] : '' ?></div>
                            </div>
                            <div class="form-group col-lg-4 col-md-4 col-sm-12 col-xs-12">
                                <label for="LastName" class="control-label">Last Name:</label>
                                <div><?= isset($contractor_details['LastName']) ? $contractor_details['LastName'] : '' ?></div>
                            </div>
                            <div class="form-group col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <label for="CompanyName" class="control-label">Company Name:</label>
                                <div><?= isset($contractor_details['CompanyName']) ? $contractor_details['CompanyName'] : '' ?></div>
                            </div>
                            <div class="form-group col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <label for="Directors" class="control-label">Directors:</label>
                                <div><?= isset($contractor_details['Directors']) ? $contractor_details['Directors'] : '' ?></div>
                            </div>
                            <div class="form-group col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <label for="Address" class="control-label">Address:</label>
                                <div><?= isset($contractor_details['Address']) ? $contractor_details['Address'] : '' ?></div>
                            </div>
                            <div class="form-group col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <label for="ScopeOfContracts" class="control-label">Scope of Contracts:</label>
                                <div><?= isset($contractor_details['ScopeOfContracts']) ? $contractor_details['ScopeOfContracts'] : '' ?></div>
                            </div>
                            <div class="form-group col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <label for="ProjectsCompleted" class="control-label">Projects Carried Out:</label>
                                <div><?= isset($contractor_details['ProjectsCarriedOut']) ? $contractor_details['ProjectsCarriedOut'] : '' ?></div>
                            </div>
                            <div class="form-group col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <label for="KeyPersonnel" class="control-label">Key Personnel:</label>
                                <div><?= isset($contractor_details['KeyPersonnel']) ? $contractor_details['KeyPersonnel'] : '' ?></div>
                            </div>
                            <div class="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <label for="BasicData" class="control-label">Basic Data:</label>
                                <div><?= isset($contractor_details['BasicData']) ? $contractor_details['BasicData'] : '' ?></div>
                            </div>
                            <br>
                            <br>
                            <br>    

                            <!-- Display associated document -->
                            <?php if ($document_qry->num_rows > 0): ?>
                                <div class="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <label for="AssociatedDocument" class="control-label">Associated Documents:</label>
                                    <?php while ($document_row = $document_qry->fetch_assoc()): ?>
                                        <div>
                                            <a href="documents/download.php?store_id=<?php echo $document_row['store_id']; ?>"><?php echo $document_row['filename']; ?></a>
                                            <a href="documents/download.php?store_id=<?php echo $document_row['store_id']; ?>" class="btn btn-sm btn-primary">Download</a>
                                            <a href="documents/view.php?store_id=<?php echo $document_row['store_id']; ?>" class="btn btn-sm btn-primary">View</a>
                                        </div>
                                    <?php endwhile; ?>
                                </div>
                            <?php endif; ?>

                            <?php if ($grading_qry->num_rows > 0): ?>
                <div class="card card-outline card-primary mt-4">
                    <div class="card-header">
                        <h3 class="card-title">Grading Information</h3>
                    </div>
                    <div class="card-body">
                        <div class="container-fluid table-container">
                            <table class="table table-hover table-striped">
                                <thead>
                                    <tr>
                                        <th>Quality of Work</th>
                                        <th>Timeliness</th>
                                        <th>Communication</th>
                                        <th>Compliance</th>
                                        <th>Cost Efficiency</th>
                                        <th>Respon-<br>siveness</th>
                                        <th>Overall Grade</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $i = 1;
                                    while ($grading_row = $grading_qry->fetch_assoc()): ?>
                                        <tr>
                                            <td><?php echo $grading_row['QualityOfWork']; ?> (<?php echo getLetterGrade($grading_row['QualityOfWork']); ?>)</td>
                                            <td><?php echo $grading_row['Timeliness']; ?> (<?php echo getLetterGrade($grading_row['Timeliness']); ?>)</td>
                                            <td><?php echo $grading_row['Communication']; ?> (<?php echo getLetterGrade($grading_row['Communication']); ?>)</td>
                                            <td><?php echo $grading_row['Compliance']; ?> (<?php echo getLetterGrade($grading_row['Compliance']); ?>)</td>
                                            <td><?php echo $grading_row['CostEfficiency']; ?> (<?php echo getLetterGrade($grading_row['CostEfficiency']); ?>)</td>
                                            <td><?php echo $grading_row['Responsiveness']; ?> (<?php echo getLetterGrade($grading_row['Responsiveness']); ?>)</td>
                                            <td><?php echo $grading_row['OverallGrade']; ?> (<?php echo getLetterGrade($grading_row['OverallGrade']); ?>)</td>
        
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            <?php endif; ?>


                        </div>
                    </div>
                </div>
                <div class="card-footer py-1 text-center">
                    <a class="btn btn-flat btn-sm btn-light bg-gradient-light border" href="./?page=consultants"><i class="fa fa-angle-left"></i> Back to List</a>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
