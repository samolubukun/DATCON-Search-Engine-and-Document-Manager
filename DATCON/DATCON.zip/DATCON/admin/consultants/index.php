<?php if($_settings->chk_flashdata('success')): ?>
<script>
	alert_toast("<?php echo $_settings->flashdata('success') ?>",'success')
</script>
<?php endif;?>

<style>
    .img-avatar{
        width:45px;
        height:45px;
        object-fit:cover;
        object-position:center center;
        border-radius:100%;
    }
    .table-container {
        overflow-x: auto;
    }
</style>
<div class="card card-outline card-primary">
	<div class="card-header">
		<h3 class="card-title">List of Consultants</h3>
		<div class="card-tools">
			<a href="javascript:void(0)" id="create_new" class="btn btn-flat btn-sm btn-primary"><span class="fas fa-plus"></span>  Add New Consultant</a>
		</div>
	</div>
	<div class="card-body">
		<div class="container-fluid table-container">
			<table class="table table-hover table-striped">
				<thead>
					<tr>
						<th>#</th>
						<th>Date Added</th>
						<th>Company Name</th>
						<th>Directors</th>
						<th>Address</th>
						<th>Scope of Services</th>
						<th>Projects Completed</th>
						<th>Key Personnel</th>
						<th>Basic Data</th>
						<th>First Name</th>
						<th>Middle Name</th>
						<th>Last Name</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>
					<?php 
						$i = 1;
						$qry = $conn->query("SELECT * FROM `consultant`");
						while($row = $qry->fetch_assoc()):
					?>
						<tr>
							<td class="text-center"><?php echo $i++; ?></td>
							<td><?php echo date("Y-m-d H:i"); ?></td>
							<td><?php echo $row['CompanyName']; ?></td>
							<td><?php echo $row['Directors']; ?></td>
							<td><?php echo $row['Address']; ?></td>
							<td><?php echo $row['ScopeOfServices']; ?></td>
							<td><?php echo $row['ProjectsCompleted']; ?></td>
							<td><?php echo $row['KeyPersonnel']; ?></td>
							<td><?php echo $row['BasicData']; ?></td>
							<td><?php echo $row['FirstName']; ?></td>
							<td><?php echo $row['MiddleName']; ?></td>
							<td><?php echo $row['LastName']; ?></td>
							<td align="center">
								 <button type="button" class="btn btn-flat btn-default btn-sm dropdown-toggle dropdown-icon" data-toggle="dropdown">
				                  		Action
				                    <span class="sr-only">Toggle Dropdown</span>
				                  </button>
				                  <div class="dropdown-menu" role="menu">
				                    <a class="dropdown-item edit_data" href="javascript:void(0)" data-id="<?php echo $row['ConsultantID']; ?>"><span class="fa fa-edit text-dark"></span> Edit</a>
									<a class="dropdown-item"
                                        href="./?page=consultants/view_consultants&id=<?php echo $row['ConsultantID'] ?>"><span
                                            class="fa fa-eye text-dark"></span> View</a>
									<div class="dropdown-divider"></div>
				                    <a class="dropdown-item delete_data" href="javascript:void(0)" data-id="<?php echo $row['ConsultantID']; ?>"><span class="fa fa-trash text-danger"></span> Delete</a>
				                  </div>
							</td>
						</tr>
					<?php endwhile; ?>
				</tbody>
			</table>
		</div>
	</div>
</div>
<script>
	$(document).ready(function(){
		$('.delete_data').click(function(){
			_conf("Are you sure to delete this consultant permanently?","delete_consultant",[$(this).attr('data-id')])
		})
		$('#create_new').click(function(){
			uni_modal("Add New Consultant Details","consultants/manage_consultant.php",'mid-large')
		})
		$('.edit_data').click(function(){
			uni_modal("Update Consultant Details","consultants/manage_consultant.php?id="+$(this).attr('data-id'),'mid-large')
		})
		$('.table td,.table th').addClass('py-1 px-2 align-middle')
		$('.table').dataTable();
	})
	function delete_consultant($id){
		start_loader();
		$.ajax({
			url:_base_url_+"classes/Master.php?f=delete_consultant",
			method:"POST",
			data:{id: $id},
			dataType:"json",
			error:err=>{
				console.log(err)
				alert_toast("An error occured.",'error');
				end_loader();
			},
			success:function(resp){
				if(typeof resp== 'object' && resp.status == 'success'){
					location.reload();
				}else{
					alert_toast("An error occured.",'error');
					end_loader();
				}
			}
		})
	}
</script>
