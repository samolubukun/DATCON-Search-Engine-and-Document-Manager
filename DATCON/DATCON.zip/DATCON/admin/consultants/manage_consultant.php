<?php
require_once('../../config.php');
if(isset($_GET['id'])){
    $qry = $conn->query("SELECT * FROM `consultant` where ConsultantID = '{$_GET['id']}'");
    if($qry->num_rows > 0){
        $res = $qry->fetch_array();
        foreach($res as $k => $v){
            if(!is_numeric($k))
            $$k = $v;
        }
    }
}
?>
<div class="container-fluid">
    <form action="" id="consultant-form">
        <input type="hidden" name="id" value="<?php echo isset($ConsultantID) ? $ConsultantID : '' ?>">
        <div class="row">
            <div class="form-group col-md-6">
                <label for="CompanyName" class="control-label">Company Name</label>
                <input type="text" name="CompanyName" id="CompanyName" class="form-control form-control-border" placeholder="Company Name" value ="<?php echo isset($CompanyName) ? $CompanyName : '' ?>" required>
            </div>
            <div class="form-group col-md-6">
                <label for="Directors" class="control-label">Directors</label>
                <input type="text" name="Directors" id="Directors" class="form-control form-control-border" placeholder="Directors" value ="<?php echo isset($Directors) ? $Directors : '' ?>" required>
            </div>
            <div class="form-group col-md-6">
                <label for="Address" class="control-label">Address</label>
                <input type="text" name="Address" id="Address" class="form-control form-control-border" placeholder="Address" value ="<?php echo isset($Address) ? $Address : '' ?>" required>
            </div>
            <div class="form-group col-md-6">
                <label for="ScopeOfServices" class="control-label">Scope of Services</label>
                <input type="text" name="ScopeOfServices" id="ScopeOfServices" class="form-control form-control-border" placeholder="Scope of Services" value ="<?php echo isset($ScopeOfServices) ? $ScopeOfServices : '' ?>" required>
            </div>
            <div class="form-group col-md-6">
                <label for="ProjectsCompleted" class="control-label">Projects Completed</label>
                <input type="text" name="ProjectsCompleted" id="ProjectsCompleted" class="form-control form-control-border" placeholder="Projects Completed" value ="<?php echo isset($ProjectsCompleted) ? $ProjectsCompleted : '' ?>" required>
            </div>
            <div class="form-group col-md-6">
                <label for="KeyPersonnel" class="control-label">Key Personnel</label>
                <input type="text" name="KeyPersonnel" id="KeyPersonnel" class="form-control form-control-border" placeholder="Key Personnel" value ="<?php echo isset($KeyPersonnel) ? $KeyPersonnel : '' ?>" required>
            </div>
            <div class="form-group col-md-6">
                <label for="BasicData" class="control-label">Basic Data</label>
                <input type="text" name="BasicData" id="BasicData" class="form-control form-control-border" placeholder="Basic Data" value ="<?php echo isset($BasicData) ? $BasicData : '' ?>" required>
            </div>
            <div class="form-group col-md-6">
                <label for="FirstName" class="control-label">First Name</label>
                <input type="text" name="FirstName" id="FirstName" class="form-control form-control-border" placeholder="First Name" value ="<?php echo isset($FirstName) ? $FirstName : '' ?>" required>
            </div>
            <div class="form-group col-md-6">
                <label for="MiddleName" class="control-label">Middle Name <em>(optional)</em></label>
                <input type="text" name="MiddleName" id="MiddleName" class="form-control form-control-border" placeholder="Middle Name (optional)" value ="<?php echo isset($MiddleName) ? $MiddleName : '' ?>">
            </div>
            <div class="form-group col-md-6">
                <label for="LastName" class="control-label">Last Name</label>
                <input type="text" name="LastName" id="LastName" class="form-control form-control-border" placeholder="Last Name" value ="<?php echo isset($LastName) ? $LastName : '' ?>" required>
            </div>
        </div>
    </form>
</div>
<script>
    $(function(){
        $('#uni_modal #consultant-form').submit(function(e){
            e.preventDefault();
            var _this = $(this)
            $('.pop-msg').remove()
            var el = $('<div>')
                el.addClass("pop-msg alert")
                el.hide()
            start_loader();
            $.ajax({
                url:_base_url_+"classes/Master.php?f=save_consultant",
				data: new FormData($(this)[0]),
                cache: false,
                contentType: false,
                processData: false,
                method: 'POST',
                type: 'POST',
                dataType: 'json',
				error:err=>{
					console.log(err)
					alert_toast("An error occurred",'error');
					end_loader();
				},
                success:function(resp){
                    if(resp.status == 'success'){
                        location.reload();
                    }else if(!!resp.msg){
                        el.addClass("alert-danger")
                        el.text(resp.msg)
                        _this.prepend(el)
                    }else{
                        el.addClass("alert-danger")
                        el.text("An error occurred due to unknown reason.")
                        _this.prepend(el)
                    }
                    el.show('slow')
                    $('html,body,.modal').animate({scrollTop:0},'fast')
                    end_loader();
                }
            })
        })
    })
</script>
