    <?php
    require_once('../../config.php');

    // Fetch data for dropdown menu
    $sql = "SELECT CONCAT(FirstName, ' ', COALESCE(MiddleName, ''), ' ', LastName) AS FullName, ContractorID AS ID, 'Contractor' AS EntityType, CompanyName FROM contractor
            UNION ALL
            SELECT CONCAT(FirstName, ' ', COALESCE(MiddleName, ''), ' ', LastName) AS FullName, ConsultantID AS ID, 'Consultant' AS EntityType, CompanyName FROM consultant";
    $result = mysqli_query($conn, $sql);
    ?>

    <label for="contractor_consultant">Select Contractor/Consultant:</label><br>
    <select id="contractor_consultant" name="contractor_consultant" required>
        <option value="">Select</option>
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
            <option value="<?php echo $row['ID'] . '|' . $row['EntityType']; ?>"><?php echo $row['FullName'] . ' (' . $row['EntityType'] . ') - ' . $row['CompanyName']; ?></option>
        <?php } ?>
    </select><br><br>

    <form action="" id="grading-form">
        <input type="hidden" name="EntityID" id="EntityID" value="">
        <input type="hidden" name="EntityType" id="EntityType" value="">
        
        <div class="row">
            <div class="form-group col-md-6">
                <label for="QualityOfWork">Quality of Work</label>
                <select id="QualityOfWork" name="QualityOfWork" required>
                    <option value="5">Excellent</option>
                    <option value="4">Good</option>
                    <option value="3">Average</option>
                    <option value="2">Poor</option>
                    <option value="1">Very Poor</option>
                </select>
            </div>
            <div class="form-group col-md-6">
                <label for="Timeliness">Timeliness</label>
                <select id="Timeliness" name="Timeliness" required>
                    <option value="5">Excellent</option>
                    <option value="4">Good</option>
                    <option value="3">Average</option>
                    <option value="2">Poor</option>
                    <option value="1">Very Poor</option>
                </select>
            </div>
            <div class="form-group col-md-6">
                <label for="Communication">Communication</label>
                <select id="Communication" name="Communication" required>
                    <option value="5">Excellent</option>
                    <option value="4">Good</option>
                    <option value="3">Average</option>
                    <option value="2">Poor</option>
                    <option value="1">Very Poor</option>
                </select>
            </div>
            <div class="form-group col-md-6">
                <label for="Compliance">Compliance</label>
                <select id="Compliance" name="Compliance" required>
                    <option value="5">Excellent</option>
                    <option value="4">Good</option>
                    <option value="3">Average</option>
                    <option value="2">Poor</option>
                    <option value="1">Very Poor</option>
                </select>
            </div>
            <div class="form-group col-md-6">
                <label for="CostEfficiency">Cost Efficiency</label>
                <select id="CostEfficiency" name="CostEfficiency" required>
                    <option value="5">Excellent</option>
                    <option value="4">Good</option>
                    <option value="3">Average</option>
                    <option value="2">Poor</option>
                    <option value="1">Very Poor</option>
                </select>
            </div>
            <div class="form-group col-md-6">
                <label for="Responsiveness">Responsiveness</label>
                <select id="Responsiveness" name="Responsiveness" required>
                    <option value="5">Excellent</option>
                    <option value="4">Good</option>
                    <option value="3">Average</option>
                    <option value="2">Poor</option>
                    <option value="1">Very Poor</option>
                </select>
            </div>
            <div class="form-group col-md-6">
                <label for="OverallGrade">Overall Grade</label>
                <input type="text" name="OverallGrade" id="OverallGrade" class="form-control form-control-border" readonly>
            </div>
        </div>

        <button type="submit" class="btn btn-primary">Submit</button>
    </form>

    <script>
    $(function(){
        $('#contractor_consultant').change(function(){
            var selected = $(this).val().split('|');
            $('#EntityID').val(selected[0]);
            $('#EntityType').val(selected[1]);
        });

        $('#grading-form').submit(function(e){
            e.preventDefault();
            var formData = $(this).serialize();
            
            $.ajax({
                url: _base_url_ + "classes/Master.php?f=save_grading",
                method: 'POST',
                data: formData,
                dataType: 'json',
                success: function(response){
                    if(response.status == 'success'){
                        location.reload();
                    } else {
                        alert('Failed to save grading.');
                    }
                },
                error: function(xhr, status, error){
                    console.error(xhr.responseText);
                    alert('An error occurred while saving grading.');
                }
            });
        });
        // Calculate overall grade
        $('select[name^="grading"]').change(function() {
            var total = 0;
            $('select[name^="grading"]').each(function() {
                total += parseInt($(this).val());
            });
            var overallGrade = total / $('select[name^="grading"]').length;
            $('#OverallGrade').val(overallGrade.toFixed(2));
        });
    });
    </script>