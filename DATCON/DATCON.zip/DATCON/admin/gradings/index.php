<?php if($_settings->chk_flashdata('success')): ?>
<script>
    alert_toast("<?php echo $_settings->flashdata('success') ?>",'success')
</script>
<?php endif;?>

<style>
    .img-avatar{
        width:45px;
        height:45px;
        object-fit:cover;
        object-position:center center;
        border-radius:100%;
    }
    .table-container {
        overflow-x: auto;
    }
</style>
<div class="card card-outline card-primary">
    <div class="card-header">
        <h3 class="card-title">Grading Information</h3>
		<div class="card-tools">
			<a href="javascript:void(0)" id="create_new" class="btn btn-flat btn-sm btn-primary"><span class="fas fa-plus"></span>  Add New Grading</a>
		</div>
    </div>
    <div class="card-body">
        <div class="container-fluid table-container">
            <table class="table table-hover table-striped">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Full Name<br>[Represented Company]</th>
                        <th>Entity ID</th>
                        <th>Entity Type</th>
                        <th>Quality of Work</th>
                        <th>Timeliness</th>
                        <th>Communication</th>
                        <th>Compliance</th>
                        <th>Cost Efficiency</th>
                        <th>Responsiveness</th>
                        <th>Overall Grade</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    function getLetterGrade($numericGrade) {
                        if ($numericGrade >= 4.5) {
                            return 'Excellent';
                        } elseif ($numericGrade >= 3.5) {
                            return 'Good';
                        } elseif ($numericGrade >= 2.5) {
                            return 'Average';
                        } elseif ($numericGrade >= 1.5) {
                            return 'Poor';
                        } else {
                            return 'Very Poor';
                        }
                    }
                    
                        $i = 1;
                        $qry = $conn->query("
                            SELECT 
                                g.*, 
                                CONCAT_WS(' ', c.FirstName, c.MiddleName, c.LastName) AS ContractorName,
                                c.CompanyName AS ContractorCompany,
                                CONCAT_WS(' ', con.FirstName, con.MiddleName, con.LastName) AS ConsultantName,
                                con.CompanyName AS ConsultantCompany
                            FROM grading g
                            LEFT JOIN contractor c ON g.EntityID = c.ContractorID AND g.EntityType = 'Contractor'
                            LEFT JOIN consultant con ON g.EntityID = con.ConsultantID AND g.EntityType = 'Consultant'
                        ");

                        while($row = $qry->fetch_assoc()):
                    ?>
                        <tr>
                            <td class="text-center"><?php echo $i++; ?></td>
                            <td><?php 
                                if ($row['EntityType'] == 'Contractor') {
                                    echo $row['ContractorName'] . '<strong> [' . $row['ContractorCompany'] . ']<strong>';
                                } elseif ($row['EntityType'] == 'Consultant') {
                                    echo $row['ConsultantName'] . '<strong> [' . $row['ConsultantCompany'] . ']<strong>';
                                }
                            ?></td>
                            <td><?php echo $row['EntityID']; ?></td>
                            <td><?php echo $row['EntityType']; ?></td>
                            <td><?php echo $row['QualityOfWork']; ?> (<?php echo getLetterGrade($row['QualityOfWork']); ?>)</td>
                            <td><?php echo $row['Timeliness']; ?> (<?php echo getLetterGrade($row['Timeliness']); ?>)</td>
                            <td><?php echo $row['Communication']; ?> (<?php echo getLetterGrade($row['Communication']); ?>)</td>
                            <td><?php echo $row['Compliance']; ?> (<?php echo getLetterGrade($row['Compliance']); ?>)</td>
                            <td><?php echo $row['CostEfficiency']; ?> (<?php echo getLetterGrade($row['CostEfficiency']); ?>)</td>
                            <td><?php echo $row['Responsiveness']; ?> (<?php echo getLetterGrade($row['Responsiveness']); ?>)</td>
                            <td><?php echo $row['OverallGrade']; ?> (<?php echo getLetterGrade($row['OverallGrade']); ?> Performance)</td>

        
                            
                            <td align="center">
                                <button type="button" class="btn btn-flat btn-default btn-sm dropdown-toggle dropdown-icon" data-toggle="dropdown">
                                    Action
                                    <span class="sr-only">Toggle Dropdown</span>
                                </button>
                                <div class="dropdown-menu" role="menu">
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item delete_data" href="javascript:void(0)" data-id="<?php echo $row['GradingID']; ?>"><span class="fa fa-trash text-danger"></span> Delete</a>
                                </div>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<script>
	$(document).ready(function(){
		$('.delete_data').click(function(){
			_conf("Are you sure to delete this Grade permanently?","delete_grade",[$(this).attr('data-id')])
		})
		$('#create_new').click(function(){
            // Popup message when adding a new grading
			alert("Consultants/Contractors should be graded once. If re-evaluation is required, the previous grading should be deleted first. Ensure to cross-check by company name to verify if graded or not before adding a grade.");
			uni_modal("Add New Grading Details","gradings/manage_grade.php",'mid-large')
		})
		$('.table td,.table th').addClass('py-1 px-2 align-middle')
		$('.table').dataTable();
	})
	function delete_grade($id){
		start_loader();
		$.ajax({
			url:_base_url_+"classes/Master.php?f=delete_grade",
			method:"POST",
			data:{id: $id},
			dataType:"json",
			error:err=>{
				console.log(err)
				alert_toast("An error occured.",'error');
				end_loader();
			},
			success:function(resp){
				if(typeof resp== 'object' && resp.status == 'success'){
					location.reload();
				}else{
					alert_toast("An error occured.",'error');
					end_loader();
				}
			}
		})
	}
</script>
